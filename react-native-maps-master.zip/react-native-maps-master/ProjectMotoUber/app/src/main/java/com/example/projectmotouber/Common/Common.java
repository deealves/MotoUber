package com.example.projectmotouber.Common;

import com.example.projectmotouber.Remote.IGoogleAPI;
import com.example.projectmotouber.Remote.RetrofitClient;

public class Common {
    public static final String baseURL = "https://maps.googleapis.com";
    public static IGoogleAPI getGoogleAPI()
    {
        return RetrofitClient.getClient(baseURL).create(IGoogleAPI.class);
    }
}
